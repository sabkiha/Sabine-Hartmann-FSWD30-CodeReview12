<?php get_header(); ?>

  <div class="container">
    <div class="row">
      <div class="col-sm-8">
        <div class="post"> 
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <div class="post-image">
        <?php if(has_post_thumbnail()) : ?>
         <?php the_post_thumbnail(); ?>
         <?php endif; ?> 
        </div> 
          <p class="blog-post-meta"><?php the_time('d.m.Y G:i'); // blog post date and time ?>
               by <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')) ?>"> <?php the_author(); // blog post author ?> </a></p>
                <h2>
                  <a href="<?php the_permalink(); // href to a specific blog post ?>">
                    <?php the_title(); // blog post title ?>
                  </a>
                </h2>    
               <p><?php the_excerpt(); // blog post content ?></p>
               <?php comments_template(); ?>
               <?php endwhile; else:  ?>
                  <p>
                    <?php echo('No Posts Found'); ?>
                  </p>
                  <?php endif; ?>

        </div> <!-- post ends here -->
      </div> <!-- col-lg-8 col-md-8 col-8 ends here-->
    
      <div class="col-sm-3 col-sm-offset-1 blog-sidebar">
          <div class="sidebar-module sidebar-module-inset">
            <?php
                 if(is_active_sidebar('sidebar')):
                 dynamic_sidebar('sidebar');
                 endif;?>
          </div>
        </div>
    </div> <!-- row ends here -->
  </div> <!-- container ends here -->

<?php get_footer(); ?>
